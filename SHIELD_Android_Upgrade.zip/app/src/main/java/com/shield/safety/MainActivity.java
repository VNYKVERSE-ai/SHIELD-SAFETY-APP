package com.shield.safety;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.util.Log;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int SMS_PERMISSION_REQUEST = 701;
    private String pendingNumbers = "";
    private String pendingMessage = "";
    private WebView webView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ShieldBridge(), "ShieldNative");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class ShieldBridge {
        @JavascriptInterface
        public void sendSOS(String contactsJson, String message) {
            runOnUiThread(() -> {
                // User explicitly initiates SOS and confirms Android permission.
                try {
                    JSONArray contacts = new JSONArray(contactsJson);
                    StringBuilder numbers = new StringBuilder();
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);
                        String phone = c.optString("phone", "").trim();
                        if (!phone.isEmpty()) {
                            if (numbers.length() > 0) numbers.append(",");
                            numbers.append(phone);
                        }
                    }
                    if (numbers.length() == 0) {
                        Toast.makeText(MainActivity.this, "Add a trusted contact first.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    pendingNumbers = numbers.toString();
                    pendingMessage = message;
                    if (checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST);
                    } else {
                        sendPendingSms();
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Could not prepare SOS SMS.", Toast.LENGTH_LONG).show();
                    Log.e("SHIELD", "SOS preparation failed", e);
                }
            });
        }
    }

    private void sendPendingSms() {
        try {
            SmsManager manager = getSystemService(SmsManager.class);
            for (String number : pendingNumbers.split(",")) {
                manager.sendTextMessage(number.trim(), null, pendingMessage, null, null);
            }
            Toast.makeText(this, "SOS SMS submitted to your phone's messaging network. Delivery is not guaranteed.", Toast.LENGTH_LONG).show();
            pendingNumbers = "";
            pendingMessage = "";
        } catch (Exception e) {
            Toast.makeText(this, "SMS could not be sent. Check SIM, signal and SMS service.", Toast.LENGTH_LONG).show();
            Log.e("SHIELD", "SMS send failed", e);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == SMS_PERMISSION_REQUEST && results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
            sendPendingSms();
        } else if (requestCode == SMS_PERMISSION_REQUEST) {
            Toast.makeText(this, "SMS permission denied. No alert was sent.", Toast.LENGTH_LONG).show();
        }
    }
}
